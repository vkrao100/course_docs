EXPERIMENTAL

Based on LX150_makomk_Test.

Trying to fit two mining cores on a single LX150.

