EXPERIMENTAL

Attempt to fit two fully unrolled makomk cores on a single LX150.