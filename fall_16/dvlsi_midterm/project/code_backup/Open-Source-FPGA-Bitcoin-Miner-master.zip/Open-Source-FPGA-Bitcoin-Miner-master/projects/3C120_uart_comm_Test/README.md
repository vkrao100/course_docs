EXPERIMENTAL

Testing the new UART Comm on an Altera 3C120 Development Kit.