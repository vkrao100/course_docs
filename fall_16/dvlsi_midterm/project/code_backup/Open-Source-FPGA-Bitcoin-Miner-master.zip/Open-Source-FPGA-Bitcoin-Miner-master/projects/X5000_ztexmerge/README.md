This project uses ZTEX's hashers to achieve higher clocking frequencies on the
X5000, X6000, and X6500 FPGA platforms.

SmartXplorer is highly recommended to achieve frequencies above 100MHz.

Code has been successfully compiled up to 200MHz.

All code remains GPL3, but sha256_pipes2.v is "Copyright (C) 2011 ZTEX GmbH"