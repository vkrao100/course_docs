Kintex7 160T Experimental Design

This project tests a fully pipelined DSP48E1 based mining core, targetting the Kintex 7 160T device.

WARNING: This code is currently untested, and may not function correctly.
