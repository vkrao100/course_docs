DISCONTINUED

Adding a NIOS II core to the DE2-115 Unoptimized Pipelined project, and 
connecting the DE2-115 to a WizNet W5100 based board. These will be used as 
controllers for the miner cores; fetching work, submitting work, and providing 
a basic web server to allow remote configuration.