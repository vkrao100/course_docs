-- EXPERIMENTAL --

Testing out modifications made by makomk:
https://github.com/makomk/Open-Source-FPGA-Bitcoin-Miner/tree/de2-115-100mhz

The changes improve the Fmax of the design, and possibly reduce area consumption.

Merging in changes manually so I can learn them up.

makomk - 15XX7BhQcZFUg47S4VKyiLygPTHTs9234J 