Testing out the Xilinx Spartan-6 LX150T Development Kit.

http://www.xilinx.com/products/boards-and-kits/AES-S6DEV-LX150T-G.htm

Trying to get the basic unoptimized mining core running, and then working
to optimize it for speed and area.