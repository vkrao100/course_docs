Improving the JTAG communication modules to support extra features
like adjusting the DCM module.