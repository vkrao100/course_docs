fpgaport = "/dev/ttyUSB0"
pools = [ \
  {
    "name": "BTC Guild", \
    "servers": [ \
      {"host": "btcguild.com", "port": 8332}, \
    ], \
    "username": "USERNAME", \
    "password": "PASSWORD", \
  }, \
]
