This is a re-implementation done by TheSeven (http://forum.bitcoin.org/index.php?action=profile;u=15929).

Features:
	* Re-implemented as VHDL.
	* Uses RS232 for communication with PC.
	* Compatible with ISE and Xilinx devices.
	* Python scripts act as the controller on the PC.

Currently no project file or device specific configuration is included. (TODO)


If you found this code useful, please feel free to donate to TheSeven:
14Jc8vWq1mPv7vWnP5VquZZgpLEtzW2vja
