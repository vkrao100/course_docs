EXPERIMENTAL

Based off LX150_makomk_Test

Designing to achieve maximum clocking speed with a single fully unrolled core.
The code has been stripped of its rolling parameters to help keep the code
less cluttered, since this will be specifically optimized for fully unrolled speed.