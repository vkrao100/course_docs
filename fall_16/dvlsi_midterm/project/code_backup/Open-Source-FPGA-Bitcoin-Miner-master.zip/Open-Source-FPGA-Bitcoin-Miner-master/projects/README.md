These folders contain many different projects, each with different approaches
to FPGA mining. Different types of SHA-256 designs, optimized versions, built-in
controller versions, and different target platforms.