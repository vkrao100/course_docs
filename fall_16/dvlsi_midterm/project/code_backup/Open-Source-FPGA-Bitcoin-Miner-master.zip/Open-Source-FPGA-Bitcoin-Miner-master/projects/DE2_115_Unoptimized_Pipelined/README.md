This project uses a DE2-115 evaluation kit to run an optimized, unrolled 
Bitcoin miner. This is mainly to show the basics of FPGA mining, and as a
good source to base more experimental approaches on.