This is a port of the normal Verilog code to run on a Xilinx device, done by teknohog (http://forum.bitcoin.org/index.php?action=profile;u=575).

Please read README.txt for more information.


Features:
	* Uses RS232 for communication with PC.
	* Compatible with ISE and Xilinx devices.
	* Python scripts act as the controller on the PC.

TODO:
	* Create a proper project file (NOTE: boldport Makefile is provided instead, at the moment)


If you found this code useful, please feel free to donate to teknohog:
1HkL2iLLQe3KJuNCgKPc8ViZs83NJyyQDM
