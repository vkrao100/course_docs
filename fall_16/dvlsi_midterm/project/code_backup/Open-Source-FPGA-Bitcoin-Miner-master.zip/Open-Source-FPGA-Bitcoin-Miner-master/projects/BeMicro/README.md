Runs a small, pipelined miner on the BeMicro SDK.

fpgaminer_top has been modified to allow a LOOP_LOG2=3 configuration
to fit on the BeMicro. This sacrafices MH/s reporting to the mining script
but has no affect on actual performance.