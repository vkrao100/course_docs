Firmware for X5000, X6000, and X6500 mining boards.

* Overclocking.
* ZTEX Hashing core.
* Rev4 Comm Module.