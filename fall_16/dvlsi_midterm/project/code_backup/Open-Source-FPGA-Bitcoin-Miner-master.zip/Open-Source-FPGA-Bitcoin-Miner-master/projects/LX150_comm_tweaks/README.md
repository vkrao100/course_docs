EXPERIMENTAL

Tweaking various aspects of the LX150_comm_Test.