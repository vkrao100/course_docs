Bitcoin SHA-256 Hashing Core

This core is fairly unoptimized, and so should be a good starting point for learning.