iverilog -o crc32_tb.vpp crc32_tb.v crc32.v
vvp crc32_tb.vpp
