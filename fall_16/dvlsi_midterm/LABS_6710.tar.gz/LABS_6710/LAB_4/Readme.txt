The folder named screenshot contains all the corresponding screenshots of the lab.

1. Schematic of the nmos device with width 1.5u
2. DC plot of the above nmos device with fixed Vgs = 3V.
3. DC plot of the above device with different Vgs from 1V to 5V.

4. Schematic of the nmos device with width 6.0u
5. DC plot of the above nmos device with fixed Vgs = 3V.
6. DC plot of the above device with different Vgs from 1V to 5V.

Ids in the first case i.e. nmos with width = 1.5u is in the orders of microamperes(uA); whereas in the second case i.e. nmos with width = 6.0u is in the orders 
of miliapmeres(mA). In essence, as the width of the nmos device increases the current through it increases as well.

7. Schematic of the inverter with nmos width = 3u and pmos width = 6u.
8. DC plot of the above mentioned inverter.

9. Schematic of the inverter with nmos width = 3u and varying pmos width from 1.5u to 7.5u.
10. DC plots of the above mentioned inverter.

Since Vdd in this case is 5V the size of the pmos device that results in a switching point closest to Vdd/2 i.e. 2.5V is 6u.

 

