We made the following cells for our library:

1.  Tiehi
2.  Tielo
3.  2 input NAND 
4.  2 input NOR
5.  Inverter
6.  Positive edge triggered D Flip Flop with asynchronous active low Clear
7.  3 input NAND
8.  3 input NOR
9.  2 input XOR
10. Buffer (for increasing the signal strength)
11. 2:1 MUX 
12. Filler Cell

All the files are in folders named same as the cells' name

Each folder contains four files:
i)   Schematic of the cell
ii)  Layout of the Cell 
iii) Verilog Testbench
iv)  Simulation waveform 

There is another folder called Synthesis_Examples that contain behavioral verilog codes of four modules and their structural codes synthesized using our library.

After running cell characterisation our D Flip Flop failed to charcaterize in 5 simulations. We think that might be due to improper setup and hold times of the flip flop. 
