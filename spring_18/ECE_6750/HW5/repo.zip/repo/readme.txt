updated bcp.py as it was giving error while finding essential rows for 5.7.1
to run the code -> python bcp.py <input.txt>

hw5_5.txt has the BCP covering problem setup for 5.5
hw5_7.txt has the BCP covering problem setup for 5.7.1
hw5_5_7.pdf has the scanned solutions for arriving at covering problem setup.